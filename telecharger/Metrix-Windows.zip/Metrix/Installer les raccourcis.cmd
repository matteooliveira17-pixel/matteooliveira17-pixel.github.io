@echo off
rem ============================================================
rem  Metrix - cree les raccourcis sur le Bureau et dans le
rem  menu Demarrer, avec l'icone du logiciel.
rem ============================================================
setlocal
set "DIR=%~dp0"
if "%DIR:~-1%"=="\" set "DIR=%DIR:~0,-1%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d = $env:DIR; $s = New-Object -ComObject WScript.Shell;" ^
  "foreach ($p in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {" ^
  "  $l = $s.CreateShortcut((Join-Path $p 'Metrix.lnk'));" ^
  "  $l.TargetPath = (Join-Path $d 'Metrix.cmd');" ^
  "  $l.WorkingDirectory = $d;" ^
  "  $l.IconLocation = (Join-Path $d 'app\metrix.ico') + ',0';" ^
  "  $l.WindowStyle = 7;" ^
  "  $l.Description = 'Metrix - releve de quantites sur plans';" ^
  "  $l.Save() }"

if errorlevel 1 (
  echo.
  echo  Les raccourcis n'ont pas pu etre crees.
  echo  Vous pouvez lancer directement "Metrix.cmd".
) else (
  echo.
  echo  Raccourcis "Metrix" crees sur le Bureau et dans le menu Demarrer.
  echo  Si vous deplacez ce dossier, relancez ce fichier.
)
echo.
pause
