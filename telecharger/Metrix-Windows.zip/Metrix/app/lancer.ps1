﻿# Metrix - lanceur Windows (appele par Metrix.cmd).
# 1. Met Metrix a jour tout seul si une nouvelle version est publiee (quelques secondes au plus, rien a faire).
# 2. Ouvre Metrix dans sa propre fenetre (Microsoft Edge ou Google Chrome, sans barre d'adresse).
# Sans connexion internet, ou si la mise a jour echoue, Metrix s'ouvre normalement dans sa version actuelle.
# Pour ne plus mettre a jour automatiquement : creer un fichier "pas-de-mise-a-jour-auto.txt" a cote de Metrix.cmd.
# Codes de sortie : 0 = Metrix ouvert ; 1 = erreur (Metrix.cmd ouvre alors Metrix lui-meme).
param([string]$Ifc = '')
$ErrorActionPreference = 'Stop'
$app  = Split-Path -Parent $MyInvocation.MyCommand.Path        # ...\Metrix\app
$root = Split-Path -Parent $app                                  # ...\Metrix
$page = Join-Path $app 'index.html'
$UPDATES = 'https://raw.githubusercontent.com/matteooliveira17-pixel/metrix-mises-a-jour/main/'

$logDir = Join-Path $env:LOCALAPPDATA 'Metrix'
$log = Join-Path $logDir 'mise-a-jour.log'
function Log([string]$t) {
  try {
    if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
    if ((Test-Path -LiteralPath $log) -and (Get-Item -LiteralPath $log).Length -gt 200000) { Remove-Item -LiteralPath $log -Force }
    Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $t) -Encoding UTF8
  } catch {}
}
function VersionOf([string]$file) {
  try { $m = [regex]::Match([IO.File]::ReadAllText($file), "METRIX_VERSION = '([0-9.]+)'"); if ($m.Success) { return $m.Groups[1].Value } } catch {}
  return $null
}
function IsNewer([string]$a, [string]$b) {   # vrai si la version a est plus recente que b ("3.10" > "3.9")
  $x = @($a.Split('.') | ForEach-Object { [int]$_ }); $y = @($b.Split('.') | ForEach-Object { [int]$_ })
  for ($i = 0; $i -lt [Math]::Max($x.Count, $y.Count); $i++) {
    $p = 0; $q = 0; if ($i -lt $x.Count) { $p = $x[$i] }; if ($i -lt $y.Count) { $q = $y[$i] }
    if ($p -ne $q) { return ($p -gt $q) }
  }
  return $false
}

# ---------- 1. mise a jour automatique ----------
if (-not (Test-Path -LiteralPath (Join-Path $root 'pas-de-mise-a-jour-auto.txt'))) {
  $tmp = $null
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $r = Invoke-WebRequest -Uri ($UPDATES + 'metrix-update.json?t=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 5 -UseBasicParsing
    $j = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()) | ConvertFrom-Json
    $cur = VersionOf $page
    $new = [string]$j.version
    if ($new -and $cur -and (IsNewer $new $cur)) {
      $zipName = 'Metrix-mise-a-jour.zip'; if ($j.windows) { $zipName = [string]$j.windows }
      $tmp = Join-Path $env:TEMP ('Metrix-maj-' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Force -Path $tmp | Out-Null
      $zip = Join-Path $tmp 'maj.zip'
      Invoke-WebRequest -Uri ($UPDATES + $zipName) -OutFile $zip -TimeoutSec 90 -UseBasicParsing
      Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $tmp 'x') -Force
      $src = Get-ChildItem -LiteralPath (Join-Path $tmp 'x') -Recurse -Filter 'index.html' | Select-Object -First 1
      if ($src -and ((VersionOf $src.FullName) -eq $new)) {
        $srcApp = $src.DirectoryName; $srcRoot = Split-Path -Parent $srcApp
        Copy-Item -LiteralPath $page -Destination (Join-Path $app 'index-precedent.html') -Force
        Copy-Item -LiteralPath $src.FullName -Destination $page -Force
        foreach ($f in @('convertir-revit.ps1', 'lancer.ps1')) {   # le script en cours est deja lu : il peut etre remplace
          $p = Join-Path $srcApp $f; if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination (Join-Path $app $f) -Force }
        }
        $p = Join-Path $srcRoot 'lanceur\Convertir Revit.cmd'
        if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination (Join-Path $root 'Convertir Revit.cmd') -Force }
        Log "mise a jour $cur -> $new"
      } else { Log "archive de mise a jour $new invalide : rien n'a ete change" }
    }
  } catch { Log ('mise a jour non faite : ' + $_.Exception.Message) }
  if ($tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

# ---------- 2. ouverture de Metrix ----------
if (-not (Test-Path -LiteralPath $page)) { exit 1 }
$url = ([Uri]$page).AbsoluteUri + '?l=2'          # l=2 : la page sait que le lanceur gere les mises a jour
if ($Ifc) { $url += '#ifc=' + $Ifc }               # « Convertir Revit » : IFC a ouvrir
$cands = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
$exe = $cands | Where-Object { $_ -and -not $_.StartsWith("\") -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $exe) { Start-Process -FilePath $page; exit 0 }   # ni Edge ni Chrome : navigateur par defaut
# profil separe : fenetre independante et metres enregistres a part (le meme qu'avant)
$prof = Join-Path $env:LOCALAPPDATA 'MetrePlan'
Start-Process -FilePath $exe -ArgumentList @(('--app="' + $url + '"'), ('--user-data-dir="' + $prof + '"'), '--allow-file-access-from-files', '--no-first-run', '--no-default-browser-check', '--window-size=1440,900')
exit 0
